
$(document).ready(function( ){
		
		$('h1').click(function(){
		$(this).fadeOut();
		});
 });